import React, { Component } from "react";

class Counter extends Component {
    state = {
        count: 0
    };

    constructor(){
        super();
        this.handleIncrement=this.handleIncrement.bind(this);
    }

    handleIncrement()  {
        this.setState({
            count:this.state.count+1
        });
    };
    render() {
        // let classes = this.getBadges();
        return (
            <React.Fragment>
                <span>{this.formatSpan()}</span>
                <button onClick={this.handleIncrement}>clickMe</button>
            </React.Fragment>
        );
    }
    formatSpan(){
        const {count} = this.state;
        return count ===0?"Zero":count;

    }
}

export default Counter;
